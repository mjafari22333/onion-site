<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8">
<meta name="description" content="Pal - CCs, CVV2s, PayPals, Ebay accounts and more - buy stolen creditcards with bitcoin"/>
<link rel="icon" type="image/icon" href="favicon.ico">	
<link rel="shortcut icon" type="image/icon" href="favicon.ico">
<title>ccPal - CCs, CVV2s, PayPals, Ebay accounts and more - buy stolen creditcards with bitcoin</title>

<style type="text/css">
body {
background:#58192E;
color:#000;
margin:0;
padding:0
}

body,.buttn,.txt,textarea,#menu a {
font:13px Verdana,Tahoma,serif
}

div {
position:relative
}

:focus {
outline:none
}

::-moz-focus-inner,img {
border:0
}

#menu {
height:60px;
margin-bottom:21px;
width:515px
}

#menu a,.buttn {
background:#1C1508;
border:2px outset #D5C2A4;
color:#BC9E70;
cursor:pointer;
font-weight:700
}

#menu a:hover,#menu a:focus,.buttn:hover,.buttn:focus {
color:#FFF
}

#menu a {
float:left;
margin-right:4px;
padding:5px 8px
}

#menu a:focus {
padding:5px 7px 5px 9px
}

#menu a,.buttn,.txt,textarea,.table1 td,.table1 th,.floatimg {
-moz-border-radius:10px;
-webkit-border-radius:10px;
border-radius:10px
}

#logo {
height:60px;
left:50%;
margin-left:93px;
position:absolute;
width:332px
}

#main {
-moz-border-radius:15px;
-moz-box-shadow:10px 10px 15px rgba(0,0,0,0.333);
-webkit-border-radius:15px;
-webkit-box-shadow:10px 10px 15px rgba(0,0,0,0.333);
background:#D5C2A4;
border:3px outset #D5C2A4;
border-radius:15px;
box-shadow:10px 10px 15px rgba(0,0,0,0.333);
margin:20px auto 30px;
padding:20px 20px 0;
width:850px
}

.buttn {
height:30px
}

.buttn,#menu a,.txt,textarea,.table1 th,.floatimg {
-moz-box-shadow:2px 2px 2px rgba(0,0,0,0.333);
-webkit-box-shadow:2px 2px 2px rgba(0,0,0,0.333);
box-shadow:2px 2px 2px rgba(0,0,0,0.333)
}

.txt {
height:24px;
margin:4px 0;
text-align:center
}

textarea {
overflow:auto;
padding:8px
}

.txt,textarea,.floatimg {
background:#6B1E38;
border:2px outset #D5C2A4;
color:#FFF
}

.txt:focus,textarea:focus {
background:#584319
}

input.checkb {
margin-top:15px
}

a:link {
font-size:16px;
text-decoration:none
}

a:link,#warning {
color:red;
font-weight:700
}

a:link,h3 {
font-family:Constantia,Georgia,serif
}

a:hover,a:focus {
color:#FFF
}

#checkout {
font-size:30px
}

h3 {
color:#584319;
font-size:28px;
font-style:italic;
line-height:9px
}

h3,#footertext {
text-shadow:0 1px 1px rgba(0,0,0,0.333)
}

hr {
border:1px solid #6B1E38
}

.table1 td,.table1 th {
padding:5px 7px;
text-align:left
}

.table1 th {
border:2px outset #D5C2A4
}

.table1 td {
background:#BC9E70
}

.floatimg {
margin:0 19px 19px 0
}

#footer {
height:60px;
width:870px
}

#footertext {
font-size:11px;
left:318px;
text-align:center;
top:29px;
width:212px
}
</style>
</head>
<body>
<?php
session_start();
$sessData = !empty($_SESSION['sessData'])?$_SESSION['sessData']:'';
if(!empty($sessData['status']['msg'])){
    $statusMsg = $sessData['status']['msg'];
    $statusMsgType = $sessData['status']['type'];
    unset($_SESSION['sessData']['status']);
}
?>
<div id="main">
<div id="logo">
<a href="index.php"><img src="logo.png" width="332" height="60" alt="logo"></a>
</div>

 <?php
        if(!empty($sessData['userLoggedIn']) && !empty($sessData['userID'])){
            include 'user.php';
            $user = new User();
            $conditions['where'] = array(
                'id' => $sessData['userID'],
            );
            $conditions['return_type'] = 'single';
            $userData = $user->getRows($conditions);
    ?>
<div id="menu">

<a href="userAccount.php?logoutSubmit=1" title="Logout">Logout</a>
<a href="orders.php" title="Your orders">Orders (0)</a>
<a href="messages.php" title="Contact support">Messages (1)</a> <br><br>
<a href="info.php" title="Frequently Answered Questions">FAQs</a>
<a href="wallet.php" title="Your Bitcoin wallet">Wallet (0.00000 &#3647;)</a>
<a href="index.php" title="Products">Products</a>

</div>

<h3>Checkout</h3>

	 Not enough balance for this order.<br><br>
	 Your bitcoin balance is 0.00000 &#3647;, Order total: 0.00818 &#3647; + shipping (min. 0.00000 &#3647;).<br><br>
	 Please add bitcoins to your wallet.<br>
	 <div id="footer">
	 <?php } ?>
</div>
</div>
</body>
</html>